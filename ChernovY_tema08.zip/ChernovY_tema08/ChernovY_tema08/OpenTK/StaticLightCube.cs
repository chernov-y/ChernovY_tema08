using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Drawing;

namespace ConsoleApp3
{
    public class StaticLightCube
    {
        public Vector3 Position { get; set; }
        public float Size { get; }
        public Color Color { get; }

        public StaticLightCube(Vector3 pos, float size)
        {
            Position = pos;
            Size = size;
            Color = Color.Yellow;
        }

        public void Draw()
        {
            GL.PushMatrix();
            GL.Translate(Position);
            GL.Color3(Color);
            float s = Size / 2f;
            GL.Disable(EnableCap.Lighting);
            GL.Begin(PrimitiveType.Quads);
            GL.Vertex3(-s, -s, s);
            GL.Vertex3(s, -s, s);
            GL.Vertex3(s, s, s);
            GL.Vertex3(-s, s, s);
            GL.Vertex3(-s, -s, -s);
            GL.Vertex3(-s, s, -s);
            GL.Vertex3(s, s, -s);
            GL.Vertex3(s, -s, -s);
            GL.Vertex3(-s, s, -s);
            GL.Vertex3(-s, s, s);
            GL.Vertex3(s, s, s);
            GL.Vertex3(s, s, -s);
            GL.Vertex3(-s, -s, -s);
            GL.Vertex3(s, -s, -s);
            GL.Vertex3(s, -s, s);
            GL.Vertex3(-s, -s, s);
            GL.Vertex3(s, -s, -s);
            GL.Vertex3(s, s, -s);
            GL.Vertex3(s, s, s);
            GL.Vertex3(s, -s, s);
            GL.Vertex3(-s, -s, -s);
            GL.Vertex3(-s, -s, s);
            GL.Vertex3(-s, s, s);
            GL.Vertex3(-s, s, -s);
            GL.End();
            GL.Enable(EnableCap.Lighting);
            GL.PopMatrix();
        }
    }
}