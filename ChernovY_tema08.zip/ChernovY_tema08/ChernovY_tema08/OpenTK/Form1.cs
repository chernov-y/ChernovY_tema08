﻿using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ConsoleApp3
{
    public partial class Form1 : Form
    {
        private GLControl glControl;

        private Cube myCube;
        private Grid grid;
        private Axes ax;
        private Camera3DIsometric cam;
        private LightCube lightCube;
        private LightSource light;
        private StaticLightCube staticLightCube;

        private float movingLightAngle = 0f;
        private float movingLightRadius = 25f;
        private float movingLightHeight = 8f;
        private float movingLightSpeed = 0.04f;

        private bool showLightCube = false;
        private bool showRotatingLight = true;

        private bool isDragging = false;
        private int previousMouseX, previousMouseY;
        private int mouseDeltaX, mouseDeltaY;

        private KeyboardState previousKeyboard;
        private bool pulseEnabled = true;

        public Form1()
        {
            InitializeComponent();

            glControl = new GLControl();
            glControl.Width = 600;
            glControl.Height = 500;
            glControl.Left = 50;
            glControl.Top = 0;
            this.Controls.Add(glControl);

            glControl.Load += GlControl_Load;
            glControl.Paint += GlControl_Paint;
            glControl.Resize += GlControl_Resize;
            glControl.MouseDown += GlControl_MouseDown;
            glControl.MouseUp += GlControl_MouseUp;
            glControl.MouseMove += GlControl_MouseMove;

            Timer timer = new Timer();
            timer.Interval = 16;
            timer.Tick += (s, e) => glControl.Invalidate();
            timer.Start();
        }

        private void GlControl_Load(object sender, EventArgs e)
        {
            GL.ClearColor(Color.FromArgb(49, 50, 51));
            GL.Enable(EnableCap.DepthTest);
            GL.DepthFunc(DepthFunction.Less);

            GL.ShadeModel(ShadingModel.Smooth);
            GL.Enable(EnableCap.Normalize);
            GL.Enable(EnableCap.ColorMaterial);
            float[] spec = { 1f, 1f, 1f, 1f };
            GL.Material(MaterialFace.Front, MaterialParameter.Specular, spec);
            GL.Material(MaterialFace.Front, MaterialParameter.Shininess, 64f);

            cam = new Camera3DIsometric();
            myCube = new Cube(new Vector3(10, 10, 10), 10f);
            grid = new Grid();
            ax = new Axes();
            lightCube = new LightCube(new Vector3(30, 20, 40), 3f);
            light = new LightSource(lightCube.Position);
            staticLightCube = new StaticLightCube(new Vector3(movingLightRadius, movingLightHeight, 0f), 3f);

            previousKeyboard = Keyboard.GetState();
        }

        private void GlControl_Paint(object sender, PaintEventArgs e)
        {
            UpdateScene();
            RenderScene();

            glControl.SwapBuffers();
        }

        private void GlControl_Resize(object sender, EventArgs e)
        {
            GL.Viewport(0, 0, glControl.Width, glControl.Height);

            Matrix4 projection = Matrix4.CreatePerspectiveFieldOfView(
                MathHelper.PiOver4,
                (float)glControl.Width / glControl.Height,
                1f, 1024f);

            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref projection);
        }

        private void UpdateScene()
        {
            var ks = Keyboard.GetState();

            if (ks[Key.W]) cam.MoveForward();
            if (ks[Key.S]) cam.MoveBackward();
            if (ks[Key.A]) cam.MoveLeft();
            if (ks[Key.D]) cam.MoveRight();
            if (ks[Key.Q]) cam.MoveUp();
            if (ks[Key.E]) cam.MoveDown();

            // toggle sursa mutabila fara pulse prin tasta O (apasa o data)
            if (ks[Key.O] && !previousKeyboard[Key.O])
            {
                showLightCube = !showLightCube;
                pulseEnabled = false; // dezactiveaza pulsarea cand aprindem/oprim prin tastatura
                if (showLightCube)
                {
                    light.SetPosition(lightCube.Position);
                    light.Enable();
                }
                else
                {
                    light.Disable();
                }
            }

            var lightPos = lightCube.Position;
            bool posChanged = false;

            if (ks[Key.I]) { lightPos.Y += 1f; posChanged = true; }
            if (ks[Key.K]) { lightPos.Y -= 1f; posChanged = true; }
            if (ks[Key.J]) { lightPos.X -= 1f; posChanged = true; }
            if (ks[Key.L]) { lightPos.X += 1f; posChanged = true; }

            if (posChanged) {
                lightCube.Position = lightPos;
                light.SetPosition(lightPos);
            }

            if (isDragging)
            {
                var rot = myCube.Rotation;
                rot.Y += mouseDeltaX;
                rot.X += mouseDeltaY;
                myCube.Rotation = rot;

                mouseDeltaX = 0;
                mouseDeltaY = 0;
            }

            if (showRotatingLight)
            {
                movingLightAngle += movingLightSpeed;
                float mx = movingLightRadius * (float)Math.Cos(movingLightAngle);
                float mz = movingLightRadius * (float)Math.Sin(movingLightAngle);
                var movingPos = new Vector3(mx, movingLightHeight, mz);
                staticLightCube.Position = movingPos;
            }

            previousKeyboard = ks;
        }

        private void RenderScene()
        {
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            cam.SetCamera();

            if (showLightCube)
            {
                light.Enable();

                float pulse = 1f;
                float r = 0.9f, g = 0.6f, b = 0.4f;

                if (pulseEnabled)
                {
                    double t = Environment.TickCount / 1000.0;
                    pulse = 0.6f + 0.4f * (float)Math.Sin(t * 4.0);
                    float hue = (float)((Math.Sin(t * 1.2) + 1.0) * 0.5);
                    r = 0.9f * (0.5f + 0.5f * hue);
                    g = 0.6f * (0.5f + 0.5f * (1f - hue));
                    b = 0.4f * (0.6f + 0.4f * (1f - hue));
                }

                float[] diffuse = { r * pulse, g * pulse, b * pulse, 1f };
                float[] ambient = { 0.08f, 0.08f, 0.08f, 1f };
                float[] spec = { 1f, 1f, 1f, 1f };

                GL.Light(LightName.Light0, LightParameter.Diffuse, diffuse);
                GL.Light(LightName.Light0, LightParameter.Ambient, ambient);
                GL.Light(LightName.Light0, LightParameter.Specular, spec);

                Vector3 target = Vector3.Zero;
                var dir = new Vector3(target.X - lightCube.Position.X, target.Y - lightCube.Position.Y, target.Z - lightCube.Position.Z);
                float[] dirArr = { dir.X, dir.Y, dir.Z };
                GL.Light(LightName.Light0, LightParameter.SpotDirection, dirArr);
                GL.Light(LightName.Light0, LightParameter.SpotCutoff, 45f);
                GL.Light(LightName.Light0, LightParameter.SpotExponent, 20f);
            }

            if (showRotatingLight)
            {
                float[] pos1 = { staticLightCube.Position.X, staticLightCube.Position.Y, staticLightCube.Position.Z, 1f };
                float[] diffuse1 = { 0.9f, 0.6f, 0.3f, 1f };
                float[] ambient1 = { 0.05f, 0.05f, 0.05f, 1f };
                float[] spec1 = { 1f, 1f, 1f, 1f };

                GL.Enable(EnableCap.Lighting);
                GL.Enable(EnableCap.Light1);
                GL.Light(LightName.Light1, LightParameter.Position, pos1);
                GL.Light(LightName.Light1, LightParameter.Diffuse, diffuse1);
                GL.Light(LightName.Light1, LightParameter.Ambient, ambient1);
                GL.Light(LightName.Light1, LightParameter.Specular, spec1);
            }
            else
            {
                GL.Disable(EnableCap.Light1);
            }

            grid.Draw();
            ax.Draw();
            myCube.Draw();

            if (showLightCube)
            {
                lightCube.Draw();
            }

            if (showRotatingLight)
            {
                staticLightCube?.Draw();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void GlControl_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                previousMouseX = e.X;
                previousMouseY = e.Y;
            }
        }

        private void ButtonIluminare1_Click(object sender, EventArgs e)
        {
            showLightCube = !showLightCube;

            pulseEnabled = true; // butonul activeaza pulsarea

            var btn = sender as Button;
            if (btn != null)
            {
                btn.Text = showLightCube ? "Inchide iluminarea" : "Aprinde Iluminarea";
            }

            if (showLightCube)
            {
                light.SetPosition(lightCube.Position);
                light.Enable();
            }
            else
            {
                light.Disable();
            }

            glControl?.Invalidate();
        }

        private void ButtoSecondSources_Click(object sender, EventArgs e)
        {
            showRotatingLight = !showRotatingLight;

            var btn = sender as Button;
            if (btn != null)
            {
                btn.Text = showRotatingLight ? "Opreste sursa rotitoare" : "Porneste sursa rotitoare";
            }

            if (!showRotatingLight)
            {
                GL.Disable(EnableCap.Light1);
            }

            glControl?.Invalidate();
        }

        private void GlControl_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            isDragging = false;
        }

        private void GlControl_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (isDragging)
            {
                mouseDeltaX = e.X - previousMouseX;
                mouseDeltaY = e.Y - previousMouseY;
                previousMouseX = e.X;
                previousMouseY = e.Y;
            }
        }
    }
}       