﻿using OpenTK;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL;


namespace ConsoleApp3
{
    public class LightSource
    {
        public Vector3 Position { get; set; }
        public Color Diffuse { get; set; }
        public Color Ambient { get; set; }
        public Color Specular { get; set; }
        public float Shininess { get; set; }

        public LightSource(Vector3 pos)
        {
            Position = pos;
            Diffuse = Color.White;
            Ambient = Color.FromArgb(60, 60, 60);
            Specular = Color.White;
            Shininess = 32f;
        }

        public void Enable()
        {
            GL.Enable(EnableCap.Lighting);
            GL.Enable(EnableCap.Light0);
            GL.Enable(EnableCap.ColorMaterial);

            // lumina
            float[] lightPos = { Position.X, Position.Y, Position.Z, 1f };
            float[] diffuseColor = { Diffuse.R / 255f, Diffuse.G / 255f, Diffuse.B / 255f, 1f };
            float[] ambientColor = { Ambient.R / 255f, Ambient.G / 255f, Ambient.B / 255f, 1f };
            float[] specColor = { Specular.R / 255f, Specular.G / 255f, Specular.B / 255f, 1f };

            GL.Light(LightName.Light0, LightParameter.Position, lightPos);
            GL.Light(LightName.Light0, LightParameter.Diffuse, diffuseColor);
            GL.Light(LightName.Light0, LightParameter.Ambient, ambientColor);
            GL.Light(LightName.Light0, LightParameter.Specular, specColor);

            // material
            GL.Material(MaterialFace.Front, MaterialParameter.Shininess, Shininess);
            GL.Material(MaterialFace.Front, MaterialParameter.Specular, specColor);
        }

        public void Disable()
        {
            GL.Disable(EnableCap.Light0);
            GL.Disable(EnableCap.Lighting);
        }
        public void SetPosition(Vector3 pos)
        {
            Position = pos;
        }
    }
}
