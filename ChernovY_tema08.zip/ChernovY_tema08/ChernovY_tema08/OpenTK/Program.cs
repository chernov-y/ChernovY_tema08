﻿using System;
using System.Windows.Forms;

namespace ConsoleApp3
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // pornim Form1 cu GLControl-ul nostru
            Application.Run(new Form1());
        }
    }
}
