﻿using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Drawing;

public class Cube
{
    public Vector3 Position { get; set; }
    public Vector3 Rotation { get; set; }   // în grade
    public float Size { get; set; }
    public Color Color { get; set; }
    public bool Wireframe { get; set; }

    public Cube(Vector3 pos, float size, bool wireframe = false)
    {
        Position = pos;
        Size = size;
        Wireframe = wireframe;
        Color = Color.White;
        Rotation = Vector3.Zero;
    }

    public void Draw()
    {
        GL.PushMatrix();

        // transformări
        GL.Translate(Position);
        GL.Rotate(Rotation.X, 1f, 0f, 0f);
        GL.Rotate(Rotation.Y, 0f, 1f, 0f);
        GL.Rotate(Rotation.Z, 0f, 0f, 1f);

        GL.Color3(Color);

        float s = Size / 2f;

        if (Wireframe)
            GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Line);
        else
            GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Fill);

        // desenăm cubul
        GL.Begin(PrimitiveType.Quads);

        // fața +Z (față)
        GL.Normal3(0f, 0f, 1f);
        GL.Vertex3(-s, -s, s);
        GL.Vertex3(s, -s, s);
        GL.Vertex3(s, s, s);
        GL.Vertex3(-s, s, s);

        // fața -Z (spate)
        GL.Normal3(0f, 0f, -1f);
        GL.Vertex3(-s, -s, -s);
        GL.Vertex3(-s, s, -s);
        GL.Vertex3(s, s, -s);
        GL.Vertex3(s, -s, -s);

        // fața +Y (sus)
        GL.Normal3(0f, 1f, 0f);
        GL.Vertex3(-s, s, -s);
        GL.Vertex3(-s, s, s);
        GL.Vertex3(s, s, s);
        GL.Vertex3(s, s, -s);

        // fața -Y (jos)
        GL.Normal3(0f, -1f, 0f);
        GL.Vertex3(-s, -s, -s);
        GL.Vertex3(s, -s, -s);
        GL.Vertex3(s, -s, s);
        GL.Vertex3(-s, -s, s);

        // fața +X (dreapta)
        GL.Normal3(1f, 0f, 0f);
        GL.Vertex3(s, -s, -s);
        GL.Vertex3(s, s, -s);
        GL.Vertex3(s, s, s);
        GL.Vertex3(s, -s, s);

        // fața -X (stânga)
        GL.Normal3(-1f, 0f, 0f);
        GL.Vertex3(-s, -s, -s);
        GL.Vertex3(-s, -s, s);
        GL.Vertex3(-s, s, s);
        GL.Vertex3(-s, s, -s);

        GL.End();

        GL.PopMatrix();
    }
}
