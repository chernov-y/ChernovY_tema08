﻿using OpenTK;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class LightCube
    {
        public Vector3 Position { get; set; }
        public float Size { get; set; }
        public Color Color { get; set; }

        public LightCube(Vector3 pos, float size)
        {
            Position = pos;
            Size = size;
            Color = Color.Yellow; 
        }

        public void Draw()
        {
            GL.PushMatrix();

            GL.Translate(Position);
            GL.Color3(Color);

            float s = Size / 2f;

            GL.Disable(EnableCap.Lighting); 

            GL.Begin(PrimitiveType.Quads);

            // front
            GL.Vertex3(-s, -s, s);
            GL.Vertex3(s, -s, s);
            GL.Vertex3(s, s, s);
            GL.Vertex3(-s, s, s);

            // back
            GL.Vertex3(-s, -s, -s);
            GL.Vertex3(-s, s, -s);
            GL.Vertex3(s, s, -s);
            GL.Vertex3(s, -s, -s);

            // top
            GL.Vertex3(-s, s, -s);
            GL.Vertex3(-s, s, s);
            GL.Vertex3(s, s, s);
            GL.Vertex3(s, s, -s);

            // bottom
            GL.Vertex3(-s, -s, -s);
            GL.Vertex3(s, -s, -s);
            GL.Vertex3(s, -s, s);
            GL.Vertex3(-s, -s, s);

            // right
            GL.Vertex3(s, -s, -s);
            GL.Vertex3(s, s, -s);
            GL.Vertex3(s, s, s);
            GL.Vertex3(s, -s, s);

            // left
            GL.Vertex3(-s, -s, -s);
            GL.Vertex3(-s, -s, s);
            GL.Vertex3(-s, s, s);
            GL.Vertex3(-s, s, -s);

            GL.End();

            GL.Enable(EnableCap.Lighting);   

            GL.PopMatrix();
        }
    }

}
